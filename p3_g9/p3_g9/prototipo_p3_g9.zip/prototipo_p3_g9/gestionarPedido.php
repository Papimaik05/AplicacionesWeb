<?php
session_start();
include_once("includes/SA/producto_SA.php");
include_once("includes/SA/pedido_SA.php");
$precioTotal = htmlspecialchars(trim(strip_tags($_POST["hidden_precioTot"])));
$pedido_SA = new pedido_SA();
$prod_SA = new producto_SA();
    $productos = '';
    $carrito = $_SESSION['carro'];
    $numArt = 0;
    foreach($carrito as $keys => $valores){
        $productos .= $valores["id"] . $valores["talla"] . $valores["unidades"];
        $prod_SA->reducirStock($valores["id"], $valores["unidades"]);
        $numArt++;
    }
    $direccion = 'FDI UCM';
    $pedido_SA->registrarPedido($_SESSION["userID"], $productos, $direccion, $precioTotal, $numArt);

    unset($_SESSION['carro']);
    header('Location:index.php');
?>