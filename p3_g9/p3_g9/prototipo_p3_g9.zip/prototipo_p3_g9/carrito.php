<?php
session_start();
require_once('includes/SA/producto_SA.php');
require_once('includes/SA/pedido_SA.php');
$producto_SA = new producto_SA(); 

    if(isset($_GET['eliminar']) && isset($_GET['id_Prod']) && isset($_GET['talla'])){
        if(count($_SESSION['carro']) > 1){
            $carrito = $_SESSION['carro'];
            foreach($carrito as $keys => $valores){
                if(($valores["id"] == $_GET['id_Prod']) && ($valores["talla"] == $_GET['talla']) ){
                    unset($_SESSION['carro'][$keys]);
                }
            } 
        }
        else{
            unset($_SESSION['carro']);
        }
                  
    }
?>

<!DOCTYPE html> 

<html>
<head>
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <meta charset="utf-8">
	<title>Carrito</title>
</head>
<?php

require('includes/comun/cabecera.php');

echo "<h1>Carrito</h1>";

if(isset($_SESSION['login']) && ($_SESSION['login'] === true) && isset($_SESSION['carro'])){
    $carrito = $_SESSION['carro'];
    $precioTotal = 0;
    foreach($carrito as $keys => $valores){
    $datos = $producto_SA->getDatosProducto($valores["id"]); // conseguimos toda la info para mostrarla 

    $nombre = $datos['nombre']; 
    $precio = $datos['precio']; 
    $talla = $valores["talla"];
    $img = $datos['img'];
    $und = $valores["unidades"];
    $precioTotal += ($precio * $und);

    echo "
    <div class=celdaProductoCarro>
        <div class='producto_carro_img'> 
            <img src='$img' alt='imagen' class='imgProductoCarro'>
            <p>$nombre </p>
        
        </div>
        <div class='datosCarro'>
            
                <p>Precio/unidad: $precio €</p>
                <p>Talla: $talla</p>
                <p>Unidades: $und</p>
                <div class='botonCancelar'>
                <button class='btn'>
                    <a href='carrito.php?id_Prod={$valores["id"]}&talla=$talla&eliminar=1'><img src='img/cancelar.png'></a>
                </button>
        </div>


       
    </div>

   
</div>
    
    ";

    }

    echo "<h2>Precio total: $precioTotal €</h2>";

    echo "<div class='botonHacerPedido'>
        <form action='gestionarPedido.php' method='POST'>
        <input type='hidden' name='hidden_precioTot' value='$precioTotal'>
        <input class='boton' type='submit' name='hacerPedido' value='Realizar pedido'>
        </form>
    </div>";
}else if(isset($_SESSION['login']) && $_SESSION['login'] === true){
    echo "<p>No ha añadido productos al carrito</p>";
}else{
    echo "<p>No ha iniciado sesión, es necesario para tener productos en el carrito</p>";
}

require('includes/comun/pie.php');
?>

</html>