<?php

session_start();

require_once('includes/SA/valoracionProduc_SA.php');

if(isset($_POST["val"])){
    $idU = $_SESSION['userID'];
    $val = htmlspecialchars(trim(strip_tags($_POST["val"])));
    $idP = htmlspecialchars(trim(strip_tags($_POST["id_prod"])));
    $val_SA = new valoracionProduc_SA();
    $val_SA->nuevaVal($idU, $idP, $val);
}

header('Location:pedidos.php');


?>
