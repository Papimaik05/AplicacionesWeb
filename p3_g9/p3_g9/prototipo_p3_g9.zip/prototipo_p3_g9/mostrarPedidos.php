<?php
require_once('includes/SA/producto_SA.php');
require_once('includes/SA/pedido_SA.php');
require_once('includes/clases/Pedido.php');
require_once('includes/SA/valoracionProduc_SA.php');
$producto_SA = new producto_SA(); 
$ped_SA = new pedido_SA();

if(isset($_GET['eliminar']) && isset($_GET['id_Ped']) ){
    $ped = new Pedido();
    $ped = $ped_SA->obtenerPedidoConId($_GET['id_Ped']);
    $art = $ped->getArticulos();
    $j = 0;
    while($j < strlen($art)){
        $idA = $art[$j];
        $j++;
        if($art[$j] == 'X'){
            $j += 2;
        }
        else{
           $j++; 
        }
        $u = $art[$j];
        $j++;
        $producto_SA->añadirStock($idA, $u);
    }
    $ped_SA->eliminarPedido($_GET['id_Ped']); 
}


if(isset($_SESSION['login']) && ($_SESSION['login'] === true)){
    if($ped_SA->contarPedidosUsuario($_SESSION['userID']) > 0){
        $result = $ped_SA->obtenerPed($_SESSION['userID']); 
        
        foreach($result as $fila){
            $id = $fila['id'];
            $articulos = $fila['articulos'];
            $precioTotal = $fila['precioTotal'];
            $direccion = $fila['direccion'];
            $numArt = $fila['numArticulos'];
            echo "<h2>Localizador Pedido: $id</h2>";
                $i = 0;
                while($i < strlen($articulos)){
                $datos = $producto_SA->getDatosProducto($articulos[$i]);
                $i++;
                if($articulos[$i] == 'X'){
                    $talla[0] = $articulos[$i];
                    $i++;
                    $talla[1] = $articulos[$i];
                }
                else{
                    $talla = $articulos[$i];
                }
                $i++;
                $und = $articulos[$i];
                $i++;
                
                $idProd = $datos['id'];
                $nombre = $datos['nombre']; 
                $precio = $datos['precio'];
                $img = $datos['img'];
                echo "<h3>$nombre</h3>
                <div class='producto_carro_img'> 
                <img src='$img' alt='imagen' class='imgProductoCarro'>
                </div>
                <p>Precio/unidad: $precio €</p>
                <p>Talla: $talla</p>
                <p>Unidades: $und</p>
                ";
                $valoracion_SA = new valoracionProduc_SA();
                if(!$valoracion_SA->existeVal($_SESSION['userID'],$idProd)){
                    echo "<h4>Valorar producto</h4>
                    <form action='valorar.php' method='POST'>
                    <input type='hidden' name='id_prod' value='$idProd'>
                    <input type='number' name='val' min='1' max='5'>
                    <input type='submit' value='Valorar'>
                    </form>"; 
                }
                
                }
                
            
            echo "<h3>Direccion: $direccion</h3>
            <h3>Precio Pedido: $precioTotal</h3>
            <button class='btn'>
                    <a href='pedidos.php?id_Ped={$id}&eliminar=1'>Devolver pedido</a>
                </button>";

    
        }
            
    }
    else{
            echo "<h1>No tiene ningun pedido realizado</h1>";
    }

}
else{
    echo "<h1>No ha iniciado sesión, es necesario para tener pedidos</h1>";
}



?>