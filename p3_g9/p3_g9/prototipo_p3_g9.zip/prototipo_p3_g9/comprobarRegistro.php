<?php
session_start(); 
include_once("includes/clases/Usuario.php"); 
include_once("includes/SA/usuario_SA.php"); 

$nombre = htmlspecialchars(trim(strip_tags($_POST["nombre"]))); 
$userID = htmlspecialchars(trim(strip_tags($_POST["userID"])));
$email = htmlspecialchars(trim(strip_tags($_POST["email"])));
$telefono = htmlspecialchars(trim(strip_tags($_POST["telefono"])));
$pass = htmlspecialchars(trim(strip_tags($_POST["pass"]))); 

$usrSAaux = new usuario_SA(); //creamos instancia SA para comunicarnos con la clase DAO del usuario

$nuevoUsr = $usrSAaux->nuevoUsrRegristro($nombre,$userID,$email,$telefono,$pass);

if($nuevoUsr){ // si todo ha ido bien en el regristro nos metemos por esta rama, en donde damos valor a las variables de sesion
    $result['exito'] = true; 
    header('location: index.php?exitoRergistro=true');

}
else{
    $result['exito'] = false; 
    $result['errors'] = 'Fallo en el registro'; 
    
    header('location:index.php?errorRergistro=true');// se trata en la cabecera
}

?>