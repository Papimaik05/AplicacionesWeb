

<?php
require_once('inicio.php');
require_once('includes/create_bd.php');
?>